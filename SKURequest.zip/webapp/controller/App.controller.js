sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Apple.SKURequest.controller.App", {
		onInit: function () {

		}
	});
});